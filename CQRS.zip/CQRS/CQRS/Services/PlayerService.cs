﻿using CQRS.Data;
using CQRS.Models;
using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace CQRS.Services
{
    public class PlayersService : IPlayersService
    {
        private readonly FootballDbContext _context;
        private readonly DapperContext _dapperContext;

        public PlayersService(FootballDbContext context, DapperContext dapperContext)
        {
            _context = context;
            _dapperContext = dapperContext;
        }

        public async Task<IEnumerable<Player>> GetPlayersList()
        {
            //return await _context.Players
            //    .ToListAsync();

            string query = "SELECT * FROM Players";

            using (var connection = _dapperContext.CreateConnection())
            {
                var companies = await connection.QueryAsync<Player>(query);
                return companies.ToList();
            }
        }

        public async Task<Player> GetPlayerById(int id)
        {
            //return await _context.Players.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            var query = "SELECT * FROM Players WHERE Id = @Id";

            using (var connection = _dapperContext.CreateConnection())
            {
                var company = await connection.QuerySingleOrDefaultAsync<Player>(query, new { id });

                return company;
            }
        }

        public async Task<Player> CreatePlayer(Player player)
        {
            _context.Players.Add(player);
            await _context.SaveChangesAsync();
            return player;

            //var query = "INSERT INTO Players (ShirtNo, Name, Appearances, Goals) VALUES (@ShirtNo, @Name, @Appearances, @Goals)" +
            //    "SELECT CAST(SCOPE_IDENTITY() as int)";

            //var parameters = new DynamicParameters();
            //parameters.Add("ShirtNo", player.ShirtNo, DbType.Int32);
            //parameters.Add("Name", player.Name, DbType.String);
            //parameters.Add("Appearances", player.Appearances, DbType.Int32);
            //parameters.Add("Goals", player.Goals, DbType.Int32);

            //using (var connection = _dapperContext.CreateConnection())
            //{

            //    await connection.ExecuteAsync(query, parameters);
            //}
            //return player;

        }

        public async Task<int> UpdatePlayer(Player player)
        {
            _context.Players.Update(player);
            return await _context.SaveChangesAsync();
        }

        public async Task<int> DeletePlayer(Player player)
        {
            _context.Players.Remove(player);
            return await _context.SaveChangesAsync();
        }
    }
}
